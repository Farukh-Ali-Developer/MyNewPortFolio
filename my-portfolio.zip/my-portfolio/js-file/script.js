var typed = new  Typed(".typing",{
    strings:["Web Developer......","Software Developer.....","Web Developer..... Front-End Developer"],
    typeSpeed:40,
    BackSpeed:90,
    loop:true
})